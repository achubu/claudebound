# Aethercede reusable belt fitting kit

Open `Aethercede-Belt-Fitter.html` in a desktop browser. It is self-contained, works offline and makes no network requests. Nothing is installed in or published to the game.

## What is implemented

- The original hero sheet is preserved unchanged as the base.
- 36 editable placement records: front, left, right, back; idle plus eight walk frames each.
- Independent per-view belt artwork, placement, dimensions, rotation and foreground protection masks.
- Four simultaneous animation previews using the existing 85 ms frame interval.
- Portable JSON projects embedding all four item images, placement records and masks.
- Transparent belt-only PNG export and equipped-character PNG export at 2304 × 1024, with original 256 px frame registration.

## First fitting pass

1. Select a direction and frame. Drag the belt into place; adjust width, height and angle.
2. Copy the fit to the other frames in this view. This keeps the individually seeded waist heights and masks; review each frame afterward.
3. Enable **Protect foreground** and paint over hands, forearms, the pouch or shirt areas that must remain in front. Clear a frame mask to repaint it.
4. Play the walk cycle. Check all four views for sliding, clipping, oversized buckle, and belt occlusion.
5. Save the editable project. Export the belt-only PNG and equipped-character PNG for review.

## Adding the next belt

Load the previous project, change the item name, and replace the selected view's artwork with a tightly cropped transparent belt PNG. Repeat for all four views. Similar silhouettes can reuse the existing fits and masks. Adjust unusually large items individually. Uploaded artwork should show the visible portion only: front buckle at the front, rear strap at the back, and independent side views. A belt design concept alone is not a finished directional asset.

## Honest limitations

This is a working fitting/editor pipeline, not a finished production belt pack. Initial waist coordinates are manually estimated and need inspection; default view artwork is provisionally cropped from the concept. Side crops are placeholders, not properly drawn side views. Automatic perspective deformation and production calibration are not implemented. Masks are painted manually and can be reused for similarly shaped items.

The original belt and brown pouch remain painted into the base. The new belt must cover the old belt; the tool cannot reconstruct concealed clothing. Removing gear or making narrower belts requires a cleaned base. The Aetherlink and all limb poses are untouched because the tool draws the original hero, rather than regenerating him. It is not a rigging system and does not fix existing gait issues.

## Handoff to Claude

Keep game-code work with Claude. Proposed runtime input: exported transparent overlay plus a validated JSON project. Rows must remain front/down, left, right, back/up; column 0 idle, columns 1–8 walk. Composite only when the outfit changes, cache by gear IDs and artwork version, and animate the resulting sheet using existing coordinates. Foreground masking is baked into overlay alpha; do not animate layers on separate clocks. Validate missing-art fallback and left-arm Aetherlink preservation.

No game integration has been performed. Exported sprites need in-motion review before release.

## Source

`fitter.template.html` is the editable application source. `build.py` embeds the original hero sheet and concept into a standalone HTML file; its input paths refer to the creation workspace. The standalone HTML needs neither Python nor the inputs. Python is used only to package source bytes; fitting and rendering occur in the browser's canvas editor.

## Validation

JavaScript syntax and offline logic checks passed for initialization, 36 placement records, project validation, copying fits while retaining waist heights, foreground masks, and sheet export dimensions. Run `node check.cjs` to repeat. The check uses a simulated canvas and does not validate rendered pixels or browser download behavior. Browser visual verification was blocked by a local connection failure. No claim of production-ready fitting is made.
