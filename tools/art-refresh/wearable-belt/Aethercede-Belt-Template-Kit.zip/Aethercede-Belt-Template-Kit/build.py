"""Package the offline equipment fitter. No game files are changed."""
import base64
from pathlib import Path
root = Path(__file__).parent
sources = {
    'HERO_DATA': root.parent / 'Aethercede-Hero-Sprite-Sheet.png',
    'BELT_DATA': root.parent / 'generated_images/exec-1e0a50ce-5900-4f72-b788-460992db5275.png',
}
html = (root / 'fitter.template.html').read_text()
for key, path in sources.items():
    html = html.replace(key, 'data:image/png;base64,' + base64.b64encode(path.read_bytes()).decode())
(root / 'Aethercede-Belt-Fitter.html').write_text(html)
print('Built self-contained fitter')
