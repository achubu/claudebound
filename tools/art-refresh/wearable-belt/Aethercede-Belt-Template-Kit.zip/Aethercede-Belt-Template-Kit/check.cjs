// Offline logic checks. This does not substitute for browser visual validation.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const elements=new Map(),outputSizes=[];
function element(){return {value:'',checked:false,selectedIndex:0,files:[],children:[],add(){},append(x){this.children.push(x)},click(){},getContext(){return {translate(){},rotate(){},drawImage(){},setTransform(){},beginPath(){},arc(){},fill(){},clearRect(){},save(){},restore(){},scale(){}}},toDataURL(){return 'data:image/png;base64,AA=='},toBlob(cb){outputSizes.push([this.width,this.height]);cb(new Blob(['test']))},getBoundingClientRect(){return {left:0,top:0,width:768,height:768}},setPointerCapture(){}};}
const doc={getElementById(id){if(!elements.has(id))elements.set(id,element());return elements.get(id)},createElement(){return element()}};
class Image {decode(){return Promise.resolve()}set src(v){this._src=v;queueMicrotask(()=>this.onload?.())}}
const context=vm.createContext({document:doc,Image,Option:class{},Blob,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}},setTimeout(){},setInterval(){},console});
const html=fs.readFileSync(__dirname+'/Aethercede-Belt-Fitter.html','utf8');
vm.runInContext(html.split('<script>')[1].split('</script>')[0],context);
setImmediate(()=>{
 assert.equal(vm.runInContext('ready',context),true);
 assert.equal(vm.runInContext('poses.flat().length',context),36);
 vm.runInContext('validate(serialize())',context);
 assert.throws(()=>vm.runInContext('validate({...serialize(),version:9})',context));
 assert.throws(()=>vm.runInContext('validate({...serialize(),artData:["bad"]})',context));
 vm.runInContext('poses[0][1].y=120;poses[0][0].w=60;$("copy").onclick()',context);
 assert.equal(vm.runInContext('poses[0][1].y',context),120);
 assert.equal(vm.runInContext('poses[0][1].w',context),60);
 vm.runInContext('paint({x:126,y:130});',context);
 assert.equal(vm.runInContext('poses[0][0].mask.length',context),1);
 vm.runInContext('$("clearMask").onclick();sheet(false);sheet(true)',context);
 assert.deepEqual(outputSizes,[[2304,1024],[2304,1024]]);
 assert.equal(vm.runInContext('poses[0][0].mask.length',context),0);
 console.log('PASS: initialization, 36 poses, project validation, copy preserving height, masks, overlay/composite export dimensions');
});
